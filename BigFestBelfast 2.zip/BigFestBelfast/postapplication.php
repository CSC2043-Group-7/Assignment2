<?php 
session_start();

include("connect.php");





print_r($_POST);

$showname = $conn->real_escape_string($_POST['showname']);
$showcategory = $_POST["showcategory"];
//$showcategory = $conn->real_escape_string($_POST['showcategory']); 
$showdescription = $conn->real_escape_string($_POST['showdescription']);
//$showruntime = $conn->real_escape_string($_POST['showruntime']);
$availabletickets = $conn->real_escape_string($_POST['availabletickets']);
$ticketprice = $conn->real_escape_string($_POST['ticketprice']);

$sentimagename = $_FILES['roughwork']['name'];
$sentimagetemp = $_FILES['roughwork']['tmp_name'];
$selectedvenue = $_GET["venueid2"];

$catid= $_POST["project"];



if(!empty($sentimagename)){
    move_uploaded_file($sentimagetemp, "img/$sentimagename");
}
else{
    echo "<p> No file selected </p>";
    die();
}


//insert into showapplication page leave for me 
$queryapply= "INSERT INTO  `showapplication` (name , category , description , availabletickets, ticketprice , imagename , venueID)
VALUES ('$showname' , '$catid' , '$showdescription', $availabletickets, $ticketprice, '$sentimagename' , $selectedvenue );";

$conn->query($queryapply) or die("query error ".$conn->error);

//insert into applications page not working 
//
//$queryapply2= "INSERT INTO  `applications` (name , description , availabletickets, ticketprice , imgpath, categoryID , venueID)
//VALUES ('$showname'  , '$showdescription',  $availabletickets, $ticketprice, '$sentimagename' , '$catid', $selectedvenue );";
//
//$conn->query($queryapply2) or die("query error ".$conn->error);


?>


<html> 
    <meta http-equiv="refresh" content="0; URL='http://jpatterson62.web.eeecs.qub.ac.uk/GroupFestival/showapplications.php'"/>
    
</html>
