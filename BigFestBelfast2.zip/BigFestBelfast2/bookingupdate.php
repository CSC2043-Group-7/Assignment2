<?php
session_start();
 $username=$_SESSION["admin_40267457"];
include("connections/conn.php");


 $showName = $_POST["show_name"];
 $startTime = $_POST["start_time"];
 $endTime = $_POST["end_time"];
 $showDate = $_POST["date"];
 $showVenue_id = $_POST["venue_id"];

	$query =$conn->query("INSERT INTO Event_Bookings( username, show_name, start_time, end_time, date, venue_id) VALUES('$username','$showName','$startTime','$endTime','$showDate', '$showVenue_id')");

	if ($query) {
		echo "Booking Successful";
		echo "<a href='shows.php'>Return to shows</a>";
	}
	
?>