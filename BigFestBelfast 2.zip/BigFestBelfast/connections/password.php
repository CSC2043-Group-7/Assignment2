<?php
//create password for database connection

$password="wHYQZV00YXk4YCPP";

