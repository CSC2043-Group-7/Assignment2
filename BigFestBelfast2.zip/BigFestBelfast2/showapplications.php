<?php
include('connections/conn.php');

$queryread = "SELECT * FROM venues";
$resultread = $conn->query($queryread);

$venueID2 = $_GET["venueid"];


//while($row5 = $resultread->fetch_assoc()){
//
//         
//       
//        $venueid = $row5["id"];
//}

if (!resultread) {
    echo $conn->error;
}


?>


 <html>
    <head>
        <title>Seven Festival</title>

   
        <link href="css/venue.css" rel="stylesheet" type="text/css">
        <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
        <script src="https://kit.fontawesome.com/d6f6f144c6.js" crossorigin="anonymous"></script>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <style>
            .borderexample {
                border-style:solid;
                border-color: black;
            }

            .infobox{
                width:450px;
                height:20px;


            }

        </style>

        <!-- Start of nav bar code -->
    <header>
        <div class="container">
            <div class="row">
                <div class='logo'>
                    <img src='img/Sevenlogo.png'> 
                </div>
                <ul class="main-nav">
                   
                    <li><a href="performervenues.php"> Venues </a></li>
                    <li><a href="performerdetails.php"> My Details </a></li>
                    <li><a href="performershows.php"> My Shows </a></li>
                    <li><a href="announcements.php"> Announcements </a></li>
                    <li><a href="logout.php"> Log out </a></li>


            </div>
            <!-- End of nav bar code -->

    </header>

</head>

<body>



    <div id='container'>
        <div class="borderexample" align="center" >
          
          <?php echo "  <form action= 'postapplication.php?venueid2=$venueID2' method='POST' id='postApplication' enctype='multipart/form-data'>"
                  ?>
                <br>
                <br>
               
                
                  <h3> Show Application </h3>
                <p> 
               
                <br>
                <p>
                    <label>Show Name</label> <br>
                    <input class="headerbox" id="header" name="showname" type="text" maxlength="100" required="required" />
                           <br> </p>
                
                <p>
                    <label>Show Category</label> <br>
                     <div>
                          <?php 
                                            $sqll="SELECT * FROM show_categories";
                                            echo "<select name='project'>";
                                            echo "<option value=''>Select One</option>";  
                                            foreach ($conn->query($sqll) as $row){
                                            echo "<option value=$row[id]>$row[category]</option>";  
                                            }
                                            echo "</select>";

                                        ?>
                    
                </div>
<!--                    <input class="headerbox" id="header" name="showcategory" type="text" maxlength="100" required="required" -->
                            </p>

                <p>
                    <label>Show Description</label> <br>
                    <input class="infobox" id="header" name="showdescription" type="text" maxlength="50" required="required" 
                           <br> </p>
                
<!--                <p>
                    <label>Show Runtime</label> <br>
                    <input class="headerbox" id="header" name="showruntime" type="text" maxlength="100" required="required" 
                           <br> </p>-->
                
<!--                <p>
                <label>Available Dates</label> <br>
                <select id="cars" name="availabledates" class="headerbox">
  <option value="volvo">Volvo</option>
  <option value="saab">Saab</option>
  <option value="fiat">Fiat</option>
  <option value="audi">Audi</option>
</select>
                </p>-->
                <p>
                    <label>Available Tickets</label> <br>
                    <input class ="headerbox" id="info" name="availabletickets" type="text" maxlength="2000" required="required" 
                           <br> </p>

                <p>
                    <label>Ticket Price</label> <br>
                    <input class ="headerbox" id="info" name="ticketprice" type="text" maxlength="2000" required="required" value=""
                           <br> </p>
                <br>
<!                <p>
                <label>Add Show Image</label> <br>
                <input name="roughwork" type="file"  />
                </p>
                
                <br>
                <br>
                <input type ="submit" text="Post Application" form="postApplication"/>


                </p>
                </p>
            </form>


        </div>
            


        <?php
        ?>  
    </div>







    <!-- Start of footer code -->
    <hr>
    <div class="footer">

        <div class="inner-footer">
            <div class="footer-items">
                <h2>Quick Links</h2>
                <div class="border"></div>
                <ul>
                    <li><a href="index.html"> Home </a></li>
                    <li><a href="shows.php"> Shows </a></li>
                    <li><a href="venue.php"> Venue </a></li>
                    <li><a href="login.php"> Login </a></li>

                </ul>
            </div>

            <div class="footer-items">
                <h2>Contact Us</h2>
                <div class="border"></div>
                <ul>
                    <li><i class="fas fa-phone"></i>02892 145834</li>
                    <li><i class="fas fa-envelope"></i>support@sevenfestival.com</li>
                </ul>

                <div class="social-media">
                    <a href="https://www.facebook.com" class="fab fa-facebook"></a>
                    <a href="https://twitter.com" class="fab fa-twitter"></a>
                    <a href="https://www.instagram.com" class="fab fa-instagram"></a>
                </div>  
            </div>

        </div>
        <div class="footer-bottom">
            Copyright &copy; Seven Festival 2020. All rights reserved.
        </div>
    </div>
    <!-- End of footer code -->
</body>
</html>

