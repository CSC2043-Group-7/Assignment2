<?php
session_start();
 $username=$_SESSION["admin_40267457"];
include('connections/conn.php');

    
    $showId = $_GET['showID'];

     $query = mysqli_query($conn,"SELECT * FROM shows INNER JOIN show_categories ON show_categories.id =shows.category_id INNER JOIN venues ON venues.id =shows.venue_id WHERE shows.id='$showId'");

    while($row=$query->fetch_assoc())
    {
      $showName = $row["show_name"];
      $startTime = $row["start_time"];
      $endTime = $row["end_time"];
      $showDate = $row["date"];
      $showCategory = $row["category"];
      $showVenue = $row["venue"];
            $venue_id = $row["id"];
    }
    
?>
<html>
    <head>
        <title>Seven Festival</title>
   
        
        <link href="css/style.css" rel="stylesheet" type="text/css">
        <link href="css/booking.css" rel="stylesheet" type="text/css">
        <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
        <script src="https://kit.fontawesome.com/d6f6f144c6.js" crossorigin="anonymous"></script>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        
    </head>
    
    <body>
      
        <header>
            <div class="container">
            <div class="row">
                <div class='logo'>
                    <img src='img/Sevenlogo.png'> 
                </div>
                <ul class="main-nav">
                    <li><a href="index.php"> Home </a></li>
                    <li class='active'><a href="shows.php"> Shows </a></li>
                    <li><a href="venue.php"> Venue </a></li>
                    <li><a href="login.php"> Login </a></li>
                </ul>     

          <form action="bookingupdate.php" method="POST">
  <div class="form-row">
    <div class="form-group col-md-6">
      <label>Username</label>
      <input type="text" value="<?php echo $username?>" class="form-control" id="username">
    </div>
  </div>
  <div class="form-group">
    <label>Show Name</label>
    <input type="text" value="<?php echo $showName ?>"  name="show_name" class="form-control" id="show_name" placeholder="Artist">
  </div>
  <div class="form-group">
    <label>Start Time</label>
    <input type="text" value="<?php echo $startTime ?>" name="start_time" class="form-control" id="start_time" placeholder="Start Time">
  </div>
  <div class="form-row">
    <div class="form-group col-md-6">
      <label>End Time</label>
      <input type="text" value="<?php echo $endTime ?>" name="end_time"class="form-control" id="end_time">
    </div>
    <div class="form-group col-md-4">
      <label>Date</label>
       <input type="text" value="<?php echo $showDate ?>" name="date" class="form-control" id="date">
    </div>
    <div class="form-group col-md-2">
      <label>Venue</label>
      <input type="text" value="<?php echo $showVenue ?>" name="venue" class="form-control" id="venue_id">
      <input type="hidden" value="<?php echo $venue_id ?>" name="venue_id" class="form-control" id="venue_id">
    </div>
        </div>
  </div>
       </label>
    </div>
  </div>
  <button type="submit" class="btn btn-primary">Reserve Ticket</button>
</form>
  </div>           
  </html>