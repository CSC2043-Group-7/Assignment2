<?php
session_start();
include("connect.php");

$selectedShowReviewID = $_GET["showreviewid"];

$reviews = "SELECT comments.id, comments.name , comments.comment , comments.showid , showapplication.id
FROM comments
INNER JOIN showapplication
ON
comments.showid = showapplication.id WHERE comments.showid = $selectedShowReviewID";
        
$reviewsresult = $conn->query($reviews);
 
?>

<html>
    <head>

        <title>Seven Festival</title>


        <link href="css/style.css" rel="stylesheet" type="text/css">
        <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">

        <script src="https://kit.fontawesome.com/d6f6f144c6.js" crossorigin="anonymous"></script>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <style>
            .borderexample {
                border-style:solid;
                border-color: black;
            }
        </style>

    </head>

    <body>
        <!-- Start of nav bar code -->
        <header>
            <div class="container">
                <div class="row">
                    <div class='logo'>
                        <img src='img/Sevenlogo.png'> 
                    </div>
                    <ul class="main-nav">
                        
                        <li><a href="venue.php"> Venues </a></li>
                        <li><a href="performerdetails.php"> My Details </a></li>
                        <li><a href="performershows.php"> My Shows </a></li>
                        <li class='active'><a href="announcements.php"> Announcements </a></li>
                        <li><a href="logout.php"> Log out </a></li>


                </div>




            </div>
            <div align="center">
           <?php
          echo " <table border=1 width='480', height='300' align='center'>
              <br>
              <br>
              <h3>Show Reviews</h3>
                
                <br>
                <br>
                
                <TR>
                    <TH style='height:30px'>Username</TH>
                    <TH style='height:30px'>Comment</TH>

                </TR> ";
           
           while ($row = $reviewsresult->fetch_assoc()) {
               
               $usernamereview = $row["name"];
               $reviewcomment = $row["comment"];
               
               echo "<TR Align=Center>
                    <TD style='height:30px'>$usernamereview</TD>
                    <TD style='height:30px'>$reviewcomment</TD>
                    </Tr> ";
               
           }
           
           ?>
           
                
                
                   
                </TR>
            </table>
            <br>
            <br>
            <?php
          echo  
           " <a href='performershowmoredetails.php?id2=$selectedShowReviewID'> Return to Show Details </a>";
            
                    ?>
            </div>
        </header>
        <!-- End of nav bar code -->



        <!-- Start of footer code -->
        <hr>
        <div class="footer">

            <div class="inner-footer">
                <div class="footer-items">
                    <h2>Quick Links</h2>
                    <div class="border"></div>
                    <ul>
                        <li><a href="index.html"> Home </a></li>
                        <li><a href="shows.php"> Shows </a></li>
                        <li><a href="venue.php"> Venue </a></li>
                        <li><a href="login.php"> Login </a></li>

                    </ul>
                </div>





                <div class="footer-items">
                    <h2>Contact Us</h2>
                    <div class="border"></div>
                    <ul>
                        <li><i class="fas fa-phone"></i>02892 145834</li>
                        <li><i class="fas fa-envelope"></i>support@sevenfestival.com</li>
                    </ul>

                    <div class="social-media">
                        <a href="https://www.facebook.com" class="fab fa-facebook"></a>
                        <a href="https://twitter.com" class="fab fa-twitter"></a>
                        <a href="https://www.instagram.com" class="fab fa-instagram"></a>
                    </div>  
                </div>

            </div>
            <div class="footer-bottom">
                Copyright &copy; Seven Festival 2020. All rights reserved.
            </div>
        </div>
        <!-- End of footer code -->
    </body>

</html>