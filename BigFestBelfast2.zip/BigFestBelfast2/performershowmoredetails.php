<?php
include("connections/conn.php");

session_start();
if (!isset($_SESSION["admin_40267457"])) 
    {
    
  header("Location: login.php") ; 
  
    }

$selectedShowID2 = $_GET["id2"];
$selectedShowID = $_GET["id"];
$selectedShowID2 = $selectedShowID;

$selectedshow = "SELECT showapplication.id , showapplication.name , showapplication.ticketprice ,showmoredetails.reservedtickets ,showmoredetails.offlinesales ,showmoredetails.availabletickets ,showapplication.imagename
                 FROM showapplication
                 LEFT JOIN showmoredetails 
                 ON showapplication.name = showmoredetails.name
                 WHERE showapplication.id = $selectedShowID";

$selectedshowResult = $conn->query($selectedshow);

$resultSelectedShow = "SELECT * FROM showmoredetails";

$resultSelectedShowQuery = $conn -> query($resultSelectedShow);
while ($row = $resultSelectedShowQuery -> fetch_assoc()) {
                    
                    $ResultShowID = $row["id"];
}
?>
<html>
    <head>
        <title>Seven Festival</title>


        <link href="css/style.css" rel="stylesheet" type="text/css">
        <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
        <script src="https://kit.fontawesome.com/d6f6f144c6.js" crossorigin="anonymous"></script>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">


        }

    </head>

    <body>
        <!-- Start of nav bar code -->
        <header>
            <div class="container">
                <div class="row">
                    <div class='logo'>
                        <img src='img/Sevenlogo.png'> 
                    </div>
                    <ul class="main-nav">
                      
                        <li><a href="performervenues.php"> Venues </a></li>
                        <li><a href="performerdetails.php"> My Details </a></li>
                        <li><a href="performershows.php"> My Shows </a></li>
                        <li><a href="announcements.php"> Announcements </a></li>
                        <li><a href="logout.php"> Log out </a></li>
                    </ul>
                </div>
            </div>

            <div>
<?php
while ($row = $selectedshowResult->fetch_assoc()) {

    $ShowID = $row["id"];
    $Showname = $row["name"];
    $TicketPrice = $row["ticketprice"];
    $ReservedTickets = $row["reservedtickets"];
    $OfflineSales = $row["offlinesales"];
    $AvailableTickets = $row["availabletickets"];
    $ImageName = $row["imagename"];

    $showVenue = $row["venue"];

    echo "<div class='box'>
                        <br><br><br>
                            <img src='img/$ImageName' height='250px'>
                          </div>
                          <div class='box'>
                            $Showname <br> <br>
                            Ticket Price: £$TicketPrice <br> <br>Reserved Tickets: $ReservedTickets <br><br>
                            Offline Sales: $OfflineSales <br><br>
                            Available Tickets: <label>$AvailableTickets</label> <br><br>
                           <a href='performerreviews.php?showreviewid=$ShowID'> Read Show Reviews </a>  
                            
                            
                          </div>";
}

//                while ($row2 = $performersResult -> fetch_assoc()) {
//                    
//                    $performerName = $row2["performer_name"];
//                    $performerDesc = $row2["performer_description"];
//                    $performerStartTime = $row2["start_time"];
//                    $performerEndTime = $row2["end_time"];
//                    
//                    echo "<div class='box'>
//                            $performerName <br>
//                            $performerDesc <br>
//                            $performerStartTime - $performerEndTime
//                          </div>";
//                }
?>


            </div>
            <div class="borderexample" align="center" >
              <?php echo  "<form action= postticketchanges.php?ptshowid=$ResultShowID method='POST'>"?>
                                    <p> 
                                    <h2>Edit Ticket Information</h2>
                                    <br>
                                    <p>
                                        <label>Offline Sales</label> <br>
                                        <input class="infobox" id="header" name="offlinesales" type="text" maxlength="50" required ="required"
                                               <br> </p>
                
                                    <style>
                                        .infobox{
                                            width:80px;
                                            height:20px;
                                            
                                            
                                            }
                                            
                
                                        
                                    </style>
                
                                    <p>
                                        <label>Available Tickets</label> <br>
                                        <input class ="infobox" id="info" name="availabletickets" type="text" maxlength="2000" required ="required"
                                               <br> </p>
                                
                
                                  
                
                                    <br>
                                    <br>
                
                
                                    <input type ="submit" value="Confirm Changes">
                
                
                                    </p>
                                    </p>
                                </form>
             


            </div>
        </div>
    </header>
    <!-- End of nav bar code -->







    <!-- Start of footer code -->
    <hr>
    <div class="footer">

        <div class="inner-footer">
            <div class="footer-items">
                <h2>Quick Links</h2>
                <div class="border"></div>
                <ul>
                    <li><a href="index.html"> Home </a></li>
                    <li><a href="shows.php"> Shows </a></li>
                    <li><a href="venue.php"> Venue </a></li>
                    <li><a href="login.php"> Login </a></li>

                </ul>
            </div>

            <div class="footer-items">
                <h2>Contact Us</h2>
                <div class="border"></div>
                <ul>
                    <li><i class="fas fa-phone"></i>02892 145834</li>
                    <li><i class="fas fa-envelope"></i>support@sevenfestival.com</li>
                </ul>

                <div class="social-media">
                    <a href="https://www.facebook.com" class="fab fa-facebook"></a>
                    <a href="https://twitter.com" class="fab fa-twitter"></a>
                    <a href="https://www.instagram.com" class="fab fa-instagram"></a>
                </div>  
            </div>

        </div>
        <div class="footer-bottom">
            Copyright &copy; Seven Festival 2020. All rights reserved.
        </div>
    </div>
    <!-- End of footer code -->
</body>

</html>