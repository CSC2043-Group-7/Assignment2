
<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
        <link rel="stylesheet" href="css/register.css">
        <script src="https://kit.fontawesome.com/c92d7e5a78.js" crossorigin="anonymous"></script>
        <script src="http://code.jquery.com/jquery-3.4.1.min.js" integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
        <title>Login</title>
    </head>
    <body>
			<div class="header">
		  	<h2>Register</h2>
		  	</div>
       
            
            <div class="login">
                <form action="newuser.php" method="POST">
                    
                    <div class="input-group" class='text-center'>
                       
					   <label>Full Name</label>
                        <input type="text" name="name" placeholder="Enter Your Name" required>
                    </div>
                    <div class="input-group" class='text-center'>
                       
					   <label>Email</label>
                        <input type="email" name="email" placeholder="Enter Your Email" required>
                    </div>
                    <div class="input-group" class='text-center'>
                       
					   <label>Username</label>
                        <input type="text" name="username" placeholder="Enter A Username" required>
                    </div>
                    <div class="input-group" class='text-center'>
                      
					  <label>Password</label>
                        <input type="password" name="password" placeholder="Enter A Password" required>
                    </div>
                    
                     <div class="radio-btns">
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="userType" id="inlineRadio1" value="RegisteredUser" required>
                            <label class="form-check-label" for="inlineRadio1">User</label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="userType" id="inlineRadio2" value="Performer" required>
                            <label class="form-check-label" for="inlineRadio2">Performer</label>
                        </div>                     
                    </div>
                   
                    <div class="input-group">
                        
                        <input type="submit" class="btn" name="register" value="Register">
                        <p>
  						Already a member? <a href="login.php">Sign in</a>
  						</p>
                    </div>
                </form>
            </div>
        
    </body>
</html>