<?php

session_start();

if (!isset($_SESSION["admin_40267457"])) {
    
  header("Location: login.php") ; 
  
}

include('../connections/conn.php');

$managerID = $_GET["managerID"];

$getScheduleQuery = "SELECT shows.image_path, shows.show_name, shows.date, shows.run_time, shows.start_time, shows.end_time, show_categories.category, shows.venue_id
                     FROM shows 
                     INNER JOIN show_categories
                     ON shows.category_id = show_categories.id
                     INNER JOIN vm_users 
                     ON shows.venue_id = vm_users.venueID  
                     WHERE vm_users.managerID = $managerID";

$getScheduleResult = $conn -> query($getScheduleQuery);

if(!$getScheduleResult){
	echo $conn -> error;
}

$loggedInManager = $_GET["managerID"];

$userIDQuery = "SELECT userID FROM vm_users WHERE managerID = $loggedInManager";

$userIDResult = $conn -> query($userIDQuery);

if (!$userIDResult) {
    echo $conn -> error;
}

while ($row2 = $userIDResult -> fetch_assoc()) {
    $userID = $row2["userID"];
}


?>


<html>
    <head>
        <title>Seven Festival</title>
   
        
        <link href="../css/venue.css" rel="stylesheet" type="text/css">
        <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
        <script src="https://kit.fontawesome.com/d6f6f144c6.js" crossorigin="anonymous"></script>
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
		
		<!-- Start of nav bar code -->
        <header>
            <div class="container">
            <div class="row">
                <div class='logo'>
                    <img src='../img/Sevenlogo.png'> 
                </div>
                <ul class="main-nav">
                    <li><a href="../index.php"> Home </a></li>
                    <li><a href="../shows.php"> Shows </a></li>
                    <li><a href="../venue.php"> Venue </a></li>
                    <?php
                    echo "<li><a href='../userhomepages/venuemanagerhomepage.php?userID=$userID'> My Profile </a></li>";
                    ?>
                    <li><a href="../logout.php"> Log Out </a></li>
                    
            
            </div>
			<!-- End of nav bar code -->
			
			</header>
        
    </head>
    
    <body>
        
			
			<div id='container'>

    <?php

    //get image names from table and display
   
     
      while($row = $getScheduleResult -> fetch_assoc()){

        $showImage = $row["image_path"]; 
        $showName = $row["show_name"];
        $showDate = $row["date"];
        $showRunTime = $row["run_time"];
        $showStartTime = $row["start_time"];
        $showEndTime = $row["end_time"];
        $showCategory = $row["category"];
        $showVenueID = $row["venue_id"];
        
        
        echo "<div class='box'> 
                <form method='POST' enctype='multipart/form-data' id='editSchedule'>
                    <label>$showName</label>
                    <br>
                    
                    <label>$showCategory</label>
                    <br>
                    
                    <img src='../gallery/$showImage' height='250px'/>
                    <br>
                    
                    <label>$showRunTime</label>
                    <br>
                    
                    <input type='date' name='showDate' value='$showDate'/>
                    <br>
                    
                    <input type='time' name='showStartTime' value='$showStartTime'/>
                    <br>
                    
                    <input type='time' name='showEndTime' value='$showEndTime'/>
                    <br>
                </form>

              </div>";
            }   
         
            echo "<br><input type='submit' value='Confirm Changes' name='confirmChanges' form='editSchedule'/>";
    ?>  
                            
                            
            <?php
                
                if(isset($_POST["confirmChanges"])) {
                    
                    $updatedShowDate = $conn -> real_escape_string ($_POST["showDate"]);
                    $updatedShowStartTime = $conn -> real_escape_string ($_POST["showStartTime"]);
                    $updatedShowEndTime = $conn -> real_escape_string ($_POST["showEndTime"]);
                    
                    $confirmScheduleQuery = "UPDATE shows
                                             SET date = '$updatedShowDate', start_time = '$updatedShowStartTime', end_time = '$updatedShowEndTime'
                                             WHERE venue_id = '$showVenueID'";
                    
                    $confirmScheduleResult = $conn -> query($confirmScheduleQuery);
                    
                    if (!$confirmScheduleResult) {
                        echo $conn -> error;
                        echo "<p>Schedule has not been updated.</p>";
                    } else {
                        echo "<p>Schedule has been updated successfully</p>"; 
                    }
                }
            
            ?>
    </div>
            
        
        
        
    

        
        <!-- Start of footer code -->
        <hr>
        <div class="footer">
            
            <div class="inner-footer">
                <div class="footer-items">
                    <h2>Quick Links</h2>
                    <div class="border"></div>
                    <ul>
                    <li><a href="../index.html"> Home </a></li>
                    <li><a href="../shows.php"> Shows </a></li>
                    <li><a href="../venue.php"> Venue </a></li>
                    <li><a href="../logout.php"> Log Out </a></li>
                    
                    </ul>
                </div>
                
                <div class="footer-items">
                    <h2>Contact Us</h2>
                    <div class="border"></div>
                    <ul>
                    <li><i class="fas fa-phone"></i>02892 145834</li>
                    <li><i class="fas fa-envelope"></i>support@BigFestBelfast.com</li>
                    </ul>
                    
                    <div class="social-media">
                        <a href="https://www.facebook.com" class="fab fa-facebook"></a>
                        <a href="https://twitter.com" class="fab fa-twitter"></a>
                        <a href="https://www.instagram.com" class="fab fa-instagram"></a>
                    </div>  
                </div>
                
            </div>
            <div class="footer-bottom">
                Copyright &copy; BigFest Belfast 2020. All rights reserved.
            </div>
        </div>
        <!-- End of footer code -->
    </body>
    
</html>
