<?php
//include password
include("password.php");
//declare MySQL username
$user = "rlewis11";
//declare webserver
$webserver = "rlewis11.hosting.eeecs.qub.ac.uk";
$db = "csc2043Group0720";

//mysqli api library in PHP to connect to the DB
$conn = new mysqli($webserver, $user, $password, $db);

if($conn->connect_errno){
    echo ("Connection failed: " . $conn->connect_error() );
}
