<?php 
session_start();

include("connect.php");



print_r($_POST);


$PTOfflinesales = $conn->real_escape_string($_POST['offlinesales']);
$PTAvailabletickets = $conn->real_escape_string($_POST['availabletickets']);

$ptshowid2 = $_GET["ptshowid"];

$PTUpdates= "UPDATE showmoredetails SET offlinesales = $PTOfflinesales , availabletickets = $PTAvailabletickets"
        . " WHERE id = $ptshowid2";
              

$conn->query($PTUpdates) or die("query error ".$conn->error);
?>

<html> 
    <meta http-equiv="refresh" content="0; URL='http://jpatterson62.web.eeecs.qub.ac.uk/GroupFestival/performershows.php'"/>
    
</html>
